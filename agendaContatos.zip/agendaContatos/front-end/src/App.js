import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
    const [nome, setNome] = useState('');
    const [email, setEmail] = useState('');
    const [telefone, setTelefone] = useState('');
    const [contatos, setContatos] = useState([]);
    const [message, setMessage] = useState('');
    const [idEditar, setIdEditar] = useState(null);
    const [pesquisa, setPesquisa] = useState('');

    useEffect(() => {
        listarContatos();
    }, []);

    const listarContatos = async () => {
        const response = await fetch('http://localhost:8080/contatos');
        const data = await response.json();
        const contatosOrdenados = data.sort((a, b) => a.nome.localeCompare(b.nome));
        setContatos(contatosOrdenados);
    };

    const cadastrarOuAtualizarContato = async (e) => {
        e.preventDefault();
        setMessage('');

        try {
            const method = idEditar ? 'PUT' : 'POST';
            const url = idEditar 
                ? `http://localhost:8080/contatos/atualizar/${idEditar}` 
                : 'http://localhost:8080/contatos/cadastrar';

            const response = await fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ nome, email, telefone }),
            });

            if (response.ok) {
                setMessage(idEditar ? 'Contato atualizado com sucesso!' : 'Contato cadastrado com sucesso!');
                listarContatos();
                resetForm();
            } else {
                const errorMessage = await response.text();
                setMessage('Erro: ' + errorMessage);
            }
        } catch (err) {
            setMessage('Erro ao salvar contato. Tente novamente.');
        }
    };

    const editarContato = (contato) => {
        setIdEditar(contato.id);
        setNome(contato.nome);
        setEmail(contato.email);
        setTelefone(contato.telefone);
    };

    const removerContato = async (id) => {
        try {
            const response = await fetch(`http://localhost:8080/contatos/deletar/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                setMessage('Contato removido com sucesso!');
                listarContatos();
            } else {
                const errorMessage = await response.text();
                setMessage('Erro: ' + errorMessage);
            }
        } catch (err) {
            setMessage('Erro ao remover contato. Tente novamente.');
        }
    };

    const resetForm = () => {
        setIdEditar(null);
        setNome('');
        setEmail('');
        setTelefone('');
    };

    const buscarPorNome = async (e) => {
        e.preventDefault();
        if (pesquisa) {
            const response = await fetch(`http://localhost:8080/contatos/buscar?nome=${pesquisa}`);
            const data = await response.json();
            const contatosOrdenados = data.sort((a, b) => a.nome.localeCompare(b.nome));
            setContatos(contatosOrdenados);
        } else {
            listarContatos();
        }
    };

    return (
        <div className="container">
            <h1>Cadastro de Contatos</h1>
            <form onSubmit={cadastrarOuAtualizarContato}>
                <input 
                    type="text" 
                    placeholder="Nome" 
                    value={nome} 
                    onChange={(e) => setNome(e.target.value)} 
                    required 
                />
                <input 
                    type="email" 
                    placeholder="E-mail" 
                    value={email} 
                    onChange={(e) => setEmail(e.target.value)} 
                    required 
                />
                <input 
                    type="text" 
                    placeholder="Telefone (XX) XXXXX-XXXX" 
                    value={telefone} 
                    onChange={(e) => setTelefone(e.target.value)} 
                    required 
                />
                <button type="submit">{idEditar ? 'Atualizar' : 'Salvar'}</button>
                <br></br>
                <button type="button" onClick={resetForm}>Cancelar</button>
            </form>
            {message && <p className="message">{message}</p>}
            <form onSubmit={buscarPorNome}>
                <input 
                    type="text" 
                    placeholder="Pesquisar por nome" 
                    value={pesquisa} 
                    onChange={(e) => setPesquisa(e.target.value)} 
                />
                <button type="submit">Pesquisar</button>
            </form>
            <h2>Contatos Cadastrados</h2>
            <ul>
                {contatos.map((contato) => (
                    <li key={contato.id}>
                        <div>{contato.nome}</div>
                        <div>{contato.email}</div>
                        <div>{contato.telefone}</div>
                        <div className="button-group">
                            <button onClick={() => editarContato(contato)}>Editar</button>
                            <button className="remove-button" onClick={() => removerContato(contato.id)}>Remover</button>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default App; 