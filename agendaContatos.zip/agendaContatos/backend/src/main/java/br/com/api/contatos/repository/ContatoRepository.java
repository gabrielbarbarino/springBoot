package br.com.api.contatos.repository;

import org.springframework.data.repository.CrudRepository;

import br.com.api.contatos.model.Contato;

import java.util.List;

public interface ContatoRepository extends CrudRepository<Contato, Long> {
    List<Contato> findByNomeContainingIgnoreCase(String nome);
    boolean existsByEmail(String email);
}