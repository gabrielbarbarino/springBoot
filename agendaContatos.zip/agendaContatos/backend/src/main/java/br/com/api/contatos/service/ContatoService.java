package br.com.api.contatos.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import br.com.api.contatos.model.Contato;
import br.com.api.contatos.repository.ContatoRepository;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ContatoService {
    private final ContatoRepository contatoRepository;

    public List<Contato> listarContatos() {
        return (List<Contato>) contatoRepository.findAll();
    }

    public List<Contato> buscarContatosPorNome(String nome) {
        return contatoRepository.findByNomeContainingIgnoreCase(nome);
    }

    public Contato criarContato(Contato contato) {
        validarContato(contato);
        return contatoRepository.save(contato);
    }

    public Contato atualizarContato(Long id, Contato contatoDetails) {
        validarContatoAtualizar(contatoDetails);
        Contato contato = contatoRepository.findById(id).orElseThrow();
        contato.setNome(contatoDetails.getNome());
        contato.setEmail(contatoDetails.getEmail());
        contato.setTelefone(contatoDetails.getTelefone());
        return contatoRepository.save(contato);
    }

    public void excluirContato(Long id) {
        contatoRepository.deleteById(id);
    }

    private void validarContato(Contato contato) {
        if (contato.getNome() == null || contato.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome não pode estar vazio.");
        }
        if (contato.getEmail() == null || !contato.getEmail().contains("@")) {
            throw new IllegalArgumentException("E-mail deve ser válido.");
        }
        if (contatoRepository.existsByEmail(contato.getEmail())) {
            throw new IllegalArgumentException("E-mail já cadastrado.");
        }
        validarTelefone(contato.getTelefone());
    }

     private void validarContatoAtualizar(Contato contato) {
        if (contato.getNome() == null || contato.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome não pode estar vazio.");
        }
        if (contato.getEmail() == null || !contato.getEmail().contains("@")) {
            throw new IllegalArgumentException("E-mail deve ser válido.");
        }
        validarTelefone(contato.getTelefone());
    }

    private void validarTelefone(String telefone) {
        if (telefone == null || telefone.length() != 14) {
            throw new IllegalArgumentException("Telefone deve seguir o padrão (XX) XXXXX-XXXX.");
        }

        if (!telefone.startsWith("(") || !telefone.contains(")")) {
            throw new IllegalArgumentException("Telefone deve seguir o padrão (XX) XXXXX-XXXX.");
        }

        if (!telefone.contains("-")) {
            throw new IllegalArgumentException("Telefone deve seguir o padrão (XX) XXXXX-XXXX.");
        }

        String numeroSemFormatacao = telefone.replaceAll("[^0-9]", "");
        if (numeroSemFormatacao.length() != 11) {
            throw new IllegalArgumentException("Telefone deve seguir o padrão (XX) XXXXX-XXXX.");
        }
    }
}