package br.com.api.contatos.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import br.com.api.contatos.model.Contato;
import br.com.api.contatos.service.ContatoService;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/contatos")
@RequiredArgsConstructor
public class ContatoController {
    private final ContatoService contatoService;

    @GetMapping
    public List<Contato> listar() {
        return contatoService.listarContatos();
    }

    @GetMapping("/buscar")
    public List<Contato> buscar(@RequestParam String nome) {
        return contatoService.buscarContatosPorNome(nome);
    }

    @PostMapping("/cadastrar")
    public ResponseEntity<?> criar(@RequestBody Contato contato) {
        try {
            Contato novoContato = contatoService.criarContato(contato);
            return ResponseEntity.status(HttpStatus.CREATED).body(novoContato);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Erro ao cadastrar contato: " + e.getMessage());
        }
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity<?> atualizar(@PathVariable Long id, @RequestBody Contato contato) {
        try {
            Contato contatoAtualizado = contatoService.atualizarContato(id, contato);
            return ResponseEntity.ok(contatoAtualizado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Erro ao atualizar contato: " + e.getMessage());
        }
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity<?> excluir(@PathVariable Long id) {
        try {
            contatoService.excluirContato(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                 .body("Erro ao excluir contato: " + e.getMessage());
        }
    }
}